import 'package:flutter/material.dart';

class DragColor_V extends StatefulWidget{
  final String Way;
  final String Dataname;

  DragColor_V({this.Way,this.Dataname});

  @override
  _DragColor_VState createState() => _DragColor_VState();
}

class _DragColor_VState extends State<DragColor_V>{

  double Height = 20.0;
  double Width = 5.0;
  double HeightBox = 20.0;
  double WidthBox = 5.0;

  @override
  Widget build(BuildContext context) {

    return  new SizedBox(
        width: WidthBox,height:HeightBox,
        child: Draggable(
          child:  Image.asset(widget.Way, width: Height,height: Width,),
          data: widget.Dataname,
          feedback: Opacity(
              opacity: 0.8,
              child: Image.asset(widget.Way,width: Height,height: Width,)),
        )
/*            onDraggableCanceled:(view , offset){
                    setState(() {
                      pos = offset;
                    });
            }*/
    );
  }

}