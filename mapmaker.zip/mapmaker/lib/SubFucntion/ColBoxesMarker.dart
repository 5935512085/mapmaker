import 'dart:ui';

import 'package:flutter/material.dart';
import 'RowBoxesMarker.dart';


class LocationDraw extends StatefulWidget{
  @override
  _LocationDrawState createState() => _LocationDrawState();
}

class _LocationDrawState extends State<LocationDraw>{

  @override
  Widget build(BuildContext context) {

    return
      Container(
        color: Colors.white,
        child: new Column(
          children: <Widget>[
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            new LineBlog(),
            Text("Scale : 50m x 50m/ mini square",style: TextStyle(fontSize: 14,color: Colors.deepOrangeAccent),)

          ],
        ),
      );
  }

}