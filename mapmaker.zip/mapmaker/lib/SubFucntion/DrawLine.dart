import 'package:flutter/material.dart';

class line_draw extends CustomPainter {
  final List<Offset> Listpost;
  final List<Color> Listcolor;
  final List<double> Listsize;
  line_draw({this.Listpost, this.Listcolor, this.Listsize});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    paint.color = Colors.black;
    for (var i = 0; i < Listpost.length; i++) {
      paint.color = Listcolor[i];
      canvas.drawCircle(Listpost[i], Listsize[i], paint);
    }
/*
    @override
    bool shouldRepaint(line_draw old) {
      return old.Listpost != Listpost;
    }*/
  }
  @override
  bool shouldRepaint(line_draw oldDelegate) {
    return oldDelegate.Listpost != Listpost;;
  }

}

