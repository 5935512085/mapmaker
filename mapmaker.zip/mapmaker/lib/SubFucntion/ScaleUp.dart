
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'RowBoxesMarker_n.dart';

class ScaleUp extends StatefulWidget {

  @override
  _ScaleUpState createState() => _ScaleUpState();
}

class _ScaleUpState extends State<ScaleUp> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: new Column(
        children: <Widget>[
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          new LineBlog_n(),
          Text("Scale : 50m x 50m/ mini square",style: TextStyle(fontSize: 14,color: Colors.deepOrangeAccent),)

        ],
      ),
    );;
  }
}
