import 'package:flutter/material.dart';

class DropLine_J extends StatefulWidget{

  @override
  _DropLine_JState createState() => _DropLine_JState();
}

class _DropLine_JState extends State<DropLine_J>{

  double height3 = 5.0;
  double width3 = 5.0;
  double height_In = 5.0;
  double width_In = 5.0;

  bool Way01Acpt = false;
  bool Way02Acpt = false;
  bool Way03Acpt = false;


  @override
  Widget build(BuildContext context) {

    return new DragTarget(
      builder: (context, List<String> data, rj){
        return Way01Acpt ?
        SizedBox(
            height: height3 ,width: width3,
            child: Image.asset("images/Way01.png",width: width_In,height: height_In,))
            : Way02Acpt ?
        SizedBox(
            height: height3 ,width: width3,
            child: Image.asset("images/Way02.png",width: width_In,height: height_In,))
            : Way03Acpt ?
        SizedBox(
            height: height3 ,width: width3,
            child: Image.asset("images/Way03.png",width: width_In,height: height_In,))
            : data.isEmpty ?
        SizedBox(
            width:width3, height: height3, child: Material(color: Colors.transparent,))
            : Opacity(opacity: 0.7,child:
        SizedBox(
          child: Container(color: Colors.blueAccent,),
          width: width_In,
          height: height_In,),);
      },

      onAccept:(data){
        if (data == 'Way01'){
          setState(() {
            Way01Acpt =true ;
          });
        }
        else if (data == 'Way02'){
          setState(() {
            Way02Acpt =true ;
          });
        }
        else if (data == 'Way03'){
          setState(() {
            Way03Acpt =true ;
          });
        }

      } ,
    );
  }

}