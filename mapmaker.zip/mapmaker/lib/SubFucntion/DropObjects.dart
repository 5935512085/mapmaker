import 'package:flutter/material.dart';

class DropFinal extends StatefulWidget{

  @override
  _DropObjectState createState() => _DropObjectState();
}

class _DropObjectState extends State<DropFinal>{

  bool Building01Acpt = false;
  bool Tree01Acpt =false;
  bool Water01Acpt = false;

  bool DeleteAcpt = false;
  double height = 25.0;
  double width = 25.0;
  double height_In = 25.0;
  double width_In = 25.0;


  bool House01Acpt = false;
  bool House02Acpt = false;

  @override
  Widget build(BuildContext context) {

    return new DragTarget(
      builder: (context, List<String> data, rj){
        return House01Acpt ?
        SizedBox(
            height: height,width: width,
            child: Image.asset("images/big1house.png",width: width_In,height: height_In,) )
            : Building01Acpt ?
        SizedBox(
            height: height ,width: width,
            child: Image.asset("images/building01.png",width: width_In,height: height_In,))
            : Tree01Acpt ?
        SizedBox(
            height: height ,width: width,
            child: Image.asset("images/tree01.png",width: width_In,height: height_In,))

            : data.isEmpty ?
        SizedBox(
            width:25 , height: 25, child: Material(color: Colors.white30,))
            : Opacity(opacity: 0.7,child:
        SizedBox(
          child: Container(color: Colors.blueAccent,),
          width: width_In,
          height: height_In,),);
      },

      onAccept:(data){
        if (data =='Tree01'){
          setState(() {
            Tree01Acpt = true;
          });
        }
        else if (data == 'House01'){
          setState(() {
            House01Acpt =true ;
          });
        }
        else if (data == 'Building01'){
          setState(() {
            Building01Acpt =true ;
          });
        }

      } ,
    );
  }

}