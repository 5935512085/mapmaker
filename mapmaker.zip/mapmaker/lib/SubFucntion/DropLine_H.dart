import 'package:flutter/material.dart';

class DropLine_H extends StatefulWidget{

  @override
  _DropLine_HState createState() => _DropLine_HState();

}


class _DropLine_HState extends State<DropLine_H >{

  double height2 = 5.0;
  double width2 = 25.0;
  double height_In = 5.0;
  double width_In = 25.0;

  bool Way01Acpt = false;
  bool Way02Acpt = false;
  bool Way03Acpt = false;


  @override
  Widget build(BuildContext context) {

    return new DragTarget(
      builder: (context, List<String> data, rj){
        return Way01Acpt ?
        SizedBox(
            height: height2 ,width: width2,
            child: Image.asset("images/Way01.png",fit: BoxFit.fitWidth))
            : Way02Acpt ?
        SizedBox(
            height: height2 ,width: width2,
            child: Image.asset("images/Way02.png",fit: BoxFit.fitWidth))
            : Way03Acpt ?
        SizedBox(
            height: height2 ,width: width2,
            child: Image.asset("images/Way03.png",fit: BoxFit.fitWidth))
            : data.isEmpty ?
        SizedBox(
            width:width2 , height: height2, child: Material(color: Colors.transparent,))
            : Opacity(opacity: 0.7,child:
              SizedBox(
                child: Container(color: Colors.blueAccent,),
                width: width_In,
                height: height_In,),);
      },

      onAccept:(data){
        if (data == 'Way01'){
          setState(() {
            Way01Acpt =true ;
          });
        }
        else if (data == 'Way02'){
          setState(() {
            Way02Acpt =true ;
          });
        }
        else if (data == 'Way03'){
          setState(() {
            Way03Acpt =true ;
          });
        }


      } ,
    );
  }

}