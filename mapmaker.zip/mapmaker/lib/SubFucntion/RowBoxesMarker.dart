import 'package:flutter/material.dart';

import 'DropLine_H.dart';
import 'DropLine_J.dart';
import 'DropLine_V.dart';
import 'DropObjects.dart';

class LineBlog extends StatefulWidget{
  @override
  _LineObjectState createState() => _LineObjectState();
}

class _LineObjectState extends State<LineBlog>{

  @override
  Widget build(BuildContext context) {

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Row(
          children: <Widget>[
            DropLine_J(), DropLine_H(),DropLine_J(), DropLine_H(),DropLine_J(), DropLine_H(),DropLine_J(),
            DropLine_H(),DropLine_J(), DropLine_H(),DropLine_J(), DropLine_H(),DropLine_J(), DropLine_H(),
            DropLine_J(), DropLine_H(),DropLine_J(), DropLine_H(),DropLine_J(), DropLine_H(),DropLine_J(),
            DropLine_H(),DropLine_J(),DropLine_H(),
          ],
        ),
        Row(
          children: <Widget>[
            DropLine_V(),DropFinal(), DropLine_V(),DropFinal(), DropLine_V(),DropFinal(), DropLine_V(),
            DropFinal(), DropLine_V(),DropFinal(), DropLine_V(),DropFinal(), DropLine_V(),DropFinal(),
            DropLine_V(),DropFinal(), DropLine_V(),DropFinal(), DropLine_V(),DropFinal(), DropLine_V(),
            DropFinal(), DropLine_V(),DropFinal()
          ],
        )

      ],

    );
  }

}