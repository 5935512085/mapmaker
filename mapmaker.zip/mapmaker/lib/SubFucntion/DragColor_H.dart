import 'package:flutter/material.dart';

class DragColor_H extends StatefulWidget{
  final String Way;
  final String Dataname;

  DragColor_H({this.Way,this.Dataname});

  @override
  _DragColor_HState createState() => _DragColor_HState();
}

class _DragColor_HState extends State<DragColor_H>{

  double Height = 5.0;
  double Width = 20.0;
  double HeightBox = 5.0;
  double WidthBox = 20.0;

  @override
  Widget build(BuildContext context) {

    return  new SizedBox(
        width: WidthBox,height:HeightBox,
        child: Draggable(
          child:  Image.asset(widget.Way, width: Height,height: Width,),
          data: widget.Dataname,
          feedback: Opacity(
              opacity: 0.8,
              child: Image.asset(widget.Way,width: Height,height: Width,)),
        )
/*            onDraggableCanceled:(view , offset){
                    setState(() {
                      pos = offset;
                    });
            }*/
    );
  }

}