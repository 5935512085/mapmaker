import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'DragObjects.dart';

class IconObjectChoices extends StatefulWidget{
  final double sizeH,sizeW;
  IconObjectChoices({this.sizeH,this.sizeW});
  @override
  _IconObjectChoicesState createState() => _IconObjectChoicesState();
}
class _IconObjectChoicesState extends State<IconObjectChoices>{
  @override
  Widget build(BuildContext context) {
    return new Container(
      child: Wrap(children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Spacer(),
            DragObject(Dataname: "Tree01",Marker: "images/tree01.png",
              sizeObjectH: widget.sizeH,sizeObjectW: widget.sizeW,),
            Spacer(),
            DragObject(Dataname: "House01",Marker: "images/big1house.png",
              sizeObjectH: widget.sizeH,sizeObjectW: widget.sizeW,),
            Spacer(),
            DragObject(Dataname: "Building01",Marker: "images/building01.png",
              sizeObjectH: widget.sizeH,sizeObjectW: widget.sizeW,),
            Spacer(),
          ],),
        Divider(),
      ], ),

    );
  }

}