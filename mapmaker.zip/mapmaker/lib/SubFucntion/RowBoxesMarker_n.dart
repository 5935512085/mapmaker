import 'package:flutter/material.dart';
import 'DropLine_H_n.dart';
import 'DropLine_J_n.dart';
import 'DropLine_V_n.dart';
import 'DropObjects_n.dart';

class LineBlog_n extends StatefulWidget{
  @override
  _LineBlog_nState createState() => _LineBlog_nState();
}

class _LineBlog_nState extends State<LineBlog_n>{

  @override
  Widget build(BuildContext context) {

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Row(
          children: <Widget>[
            DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),
            DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),
            DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),DropLine_J_n(),DropLine_H_n(),
          ],
        ),
        Row(
          children: <Widget>[
            DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),
            DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),
            DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),DropLine_V_n(),DropFinal_n(),
          ],
        )

      ],

    );
  }

}