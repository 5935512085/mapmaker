import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:mapmaker/SubFucntion/DragList.dart';
import 'package:mapmaker/SubFucntion/DragObjects.dart';
import 'BlockDrop.dart';
import 'BlockDropWay.dart';
import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;


class Canvas2D extends StatefulWidget {

  @override
  _Canvas2DState createState() => _Canvas2DState();
  double sizeH = 30.0, sizeW = 30.0;
  double SizeJW = 5.0,SizeJH = 5.0;
  double SizeVW = 5.0,SizeVH = 30.0;
  double SizeHW = 30.0,SizeHH = 5.0;
  double SizeDragH = 5.0,SizeDragW=5.0;
  String stateScale = "Zoom Way Out";
  bool val = false;
}

BoxDecoration Txborder(){
  return BoxDecoration(
      border: Border.all(
          width: 1,
          color: Colors.white ),
      borderRadius: BorderRadius.all(
          Radius.circular((8.0))),
      color: Colors.orangeAccent
  );
}

class _Canvas2DState extends State<Canvas2D> {
  GlobalKey  _screen = new GlobalKey();

  @override
  Widget build(BuildContext context) {
    return  new Scaffold(
      appBar: new AppBar(
        title: new Text(" Map2D 150m X 150m "),
        backgroundColor: Colors.deepOrangeAccent,),
      body: RepaintBoundary(
        key: _screen,
        child: new Container(
          width: double.infinity,height: double.infinity,
          child: new Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Text("  Reference Area | (SizeBox : BlockMater) ",style:TextStyle(color: Colors.black87,fontSize: 16)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                    Text(" 30x30 : 15x15,",style:TextStyle(color: Colors.black54,fontSize: 15),),
                    Text(" 5x5 : 1.5x1.5,",style:TextStyle(color: Colors.orangeAccent,fontSize: 15),),
                  ],),
                  Text(" 5x30 : 1.5x15, 5x30 : 15x1.5 ",style:TextStyle(color: Colors.orangeAccent,fontSize: 15)),
                ],
              ),
              Divider(),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                 BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH),
                  BlockDropWay(widget.SizeVW,widget.SizeVH),BlockDrop(widget.sizeW, widget.sizeH), BlockDropWay(widget.SizeVW,widget.SizeVH)
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH), BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),
                  BlockDropWay(widget.SizeJW, widget.SizeJH),BlockDropWay(widget.SizeHW, widget.SizeHH),BlockDropWay(widget.SizeJW, widget.SizeJH)
                ],
              ),

              Divider(),
              new IconObjectChoices(sizeH:30.0,sizeW: 30.0,),
              Row(children: <Widget>[
                new FlatButton(child: new Container(child: Row(children: <Widget>[
                      new Switch(value: widget.val,
                        onChanged:(bool e)=> status(e),
                        activeColor: Colors.orangeAccent ,activeTrackColor: Colors.orange[10],),
                          new Text(widget.stateScale,style: TextStyle(color: Colors.orangeAccent),),
                        ],


                  ),
                ),
              ),
                Spacer(),
                DragObject(Dataname: "Way01",Marker: "images/Way01.png",
                  sizeObjectH: widget.SizeDragH,sizeObjectW: widget.SizeDragW,),
                Spacer(),
                DragObject(Dataname: "Way02",Marker: "images/Way02.png",
                  sizeObjectH: widget.SizeDragH,sizeObjectW: widget.SizeDragW,),
                Spacer(),
                DragObject(Dataname: "Way03",Marker: "images/Way03.png",
                  sizeObjectH: widget.SizeDragH,sizeObjectW: widget.SizeDragW,),
                Spacer(),

            ],),
              Row(mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                new FlatButton(
                  child: new Container(
                    child: Text(" Save "),
                ),
                  onPressed: (){
                    _captureScreenshot(_screen);
                  },
                ),
              ],),

        ],),),
      ),
    );
  }
  void status(bool e){
    setState(() {
      if(e){
        widget.val = e;
        widget.sizeH = 17.5;
        widget.sizeW = 17.5;
        widget.SizeJH = 17.5;
        widget.SizeJW = 17.5;
        widget.SizeHW = 17.5;
        widget.SizeHH = 17.5;
        widget.SizeVW = 17.5;
        widget.SizeVH = 17.5;
        widget.SizeDragH = 17.5;
        widget.SizeDragW= 17.5;
        widget.stateScale = "Zoom Way Up";
      } else{
        widget.val = e;
        widget.sizeH = 30.0;
        widget.sizeW = 30.0;
        widget.SizeJH = 5.0;
        widget.SizeJW = 5.0;
        widget.SizeHW = 30.0;
        widget.SizeHH = 5.0;
        widget.SizeVW = 5.0;
        widget.SizeVH = 30.0;
        widget.SizeDragH = 5.0;
        widget.SizeDragW= 5.0;
        widget.stateScale = "Zoom Way Out";
      }
    });
  }
  _captureScreenshot(_screen) async{
    RenderRepaintBoundary boundary = _screen.currentContext.findRenderObject();
    ui.Image image = await boundary.toImage();
    ByteData byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    byteData.buffer.asUint8List();
  }

}
