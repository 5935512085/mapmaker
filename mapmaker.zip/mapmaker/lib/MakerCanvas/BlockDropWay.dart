import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BlockDropWay extends StatefulWidget{
  final double sizeW;
  final double sizeH;
  BlockDropWay(this.sizeW,this.sizeH);
  @override
  _BlockDropWayState createState() => _BlockDropWayState();
}


class _BlockDropWayState extends State<BlockDropWay> {
  bool Way1Acpt = false;
  bool Way2Acpt =false;
  bool Way3Acpt = false;

  @override
  Widget build(BuildContext context) {
    return new DragTarget(
      builder: (context, List<String> data, rj){
        return Way1Acpt ?
        SizedBox(
            height: widget.sizeH,width: widget.sizeW,
            child: Image.asset("images/Way01.png",
              height: widget.sizeH,width: widget.sizeW,fit: BoxFit.fill,) )
            : Way2Acpt ?
        SizedBox(
            height: widget.sizeH,width: widget.sizeW,
            child: Image.asset("images/Way02.png",
              height: widget.sizeH,width: widget.sizeW,fit: BoxFit.fill))
            : Way3Acpt ?
        SizedBox(
            height: widget.sizeH,width: widget.sizeW,
            child: Image.asset("images/Way03.png",
              height: widget.sizeH,width: widget.sizeW,fit: BoxFit.fill))

            : data.isEmpty ?
        SizedBox(
            height: widget.sizeH,width: widget.sizeW,
            child: Container(color: Colors.grey[90],
              child: Icon(Icons.add,size: 8.0,color: Colors.orangeAccent,)))
            : Opacity(
                opacity: 0.7,
                child: SizedBox(
                    child: Container(
                      color: Colors.blueAccent,),
                  height: widget.sizeH,width: widget.sizeW,),);
      },

      onAccept:(data){
        if (data =='Way01'){
          setState(() {
            Way1Acpt = true;
          });
        }
        else if (data == 'Way02'){
          setState(() {
            Way2Acpt =true ;
          });
        }
        else if (data == 'Way03'){
          setState(() {
            Way3Acpt = true ;
          });
        }

      } ,
    );
  }
}




