import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BlockDrop extends StatefulWidget{

  final double SizeH;
  final double SizeW;
  BlockDrop(this.SizeW,this.SizeH);
     @override
    _BlockDropState createState() => _BlockDropState();
}

class _BlockDropState extends State<BlockDrop> {
  BoxDecoration BoXBorder(){
    return BoxDecoration(
      border: Border.all(
          width: 1,
          color: Colors.grey ),
      borderRadius: BorderRadius.all(
          Radius.circular((5.0)))
    );
  }

  bool Building01Acpt = false;
  bool Tree01Acpt =false;
  bool Water01Acpt = false;

  bool DeleteAcpt = false;

  bool House01Acpt = false;
  bool House02Acpt = false;

  @override
  Widget build(BuildContext context) {

    return new DragTarget(
      builder: (context, List<String> data, rj){
        return House01Acpt ?
        new SizedBox(
            height: widget.SizeH,width: widget.SizeW,
            child: Image.asset("images/big1house.png",
              height: widget.SizeH,width: widget.SizeW,) )
            : Building01Acpt ?
        new SizedBox(
            height: widget.SizeH,width: widget.SizeW,
            child: Image.asset("images/building01.png",
                height: widget.SizeH,width: widget.SizeW,))
            : Tree01Acpt ?
        new SizedBox(
            height: widget.SizeH,width: widget.SizeW,
            child: Image.asset("images/tree01.png",
              height: widget.SizeH,width: widget.SizeW,))
            : data.isEmpty ?
        new SizedBox(
            height: widget.SizeH,width: widget.SizeW,
            child: Container(
                decoration: BoXBorder(),
                child: Icon(Icons.add,color: Colors.grey,size: 9.0,),))
            : Opacity(opacity: 0.7,child:
              SizedBox(
                child: Container(
                  color: Colors.blueAccent,),
                height: widget.SizeH,width: widget.SizeW,),);
      },
      onAccept:(data){
        if (data =='Tree01'){
          setState(() {
            Tree01Acpt = true;
          });
        }
        else if (data == 'House01'){
          setState(() {
            House01Acpt =true ;
          });
        }
        else if (data == 'Building01'){
          setState(() {
            Building01Acpt =true ;
          });
        }
      } ,
    );
  }
}




