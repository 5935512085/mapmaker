import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'MakerCanvas/Canvas2D.dart';


void main(){
  runApp(new MaterialApp(
    home: new Homepage(),
    routes: <String, WidgetBuilder>{
      "/Canvas2D1": (BuildContext context) => new Canvas2D()
    },
  ));
}

class Homepage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(" Map Maker "),
        backgroundColor: Colors.deepOrangeAccent,),
      body: new Container(
        child: new Center(
          child: Wrap(children: [
            Container( height: 60, width: 300,
              child: Column(
                children: <Widget>[
                  Text("Welcome to 3D Map Maker V.2",
                    style: TextStyle(
                        fontSize: 20, color: Colors.blueAccent),
                        textAlign: TextAlign.center,),
                  Text(" How to make the Map ?",
                    style: TextStyle(
                        fontSize: 18,color: Colors.lightBlueAccent),
                        textAlign: TextAlign.center,),
                ],
              ),
            ),
            Container(
              height: 120, width: 300,
              color: Colors.blueGrey[20],
              child: Column(
                children: <Widget>[
                  Text("  Choose scale area to design 2D map ",
                    style: TextStyle(
                        fontSize: 16,color: Colors.black),
                        textAlign: TextAlign.center,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      RaisedButton(
                        color: Colors.blueAccent,
                        textColor: Colors.white,
                        highlightColor: Colors.red,
                        onPressed: (){
                          Navigator.of(context).pushNamed("/Canvas2D1");
                        },
                        child: Text(" 150m X 150m ",style: TextStyle(fontSize: 14)),
                      ),
                      Spacer(),
                      RaisedButton(
                        color: Colors.blueAccent,
                        textColor: Colors.white,
                        highlightColor: Colors.red,
                        onPressed: (){},
                        child: Text(" 300m X 300m ",style: TextStyle(fontSize: 14)),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      RaisedButton(
                        color: Colors.blueAccent,
                        textColor: Colors.white,
                        highlightColor: Colors.red,
                        onPressed: (){},
                        child: Text(" 400m X 400m ",style: TextStyle(fontSize: 14)),
                      ),
                      Spacer(),
                      RaisedButton(
                        color: Colors.blueAccent,
                        textColor: Colors.white,
                        highlightColor: Colors.red,
                        onPressed: (){},
                        child: Text(" 500m X 500m ",style: TextStyle(fontSize: 14)),
                      ),
                    ],
                  ),
                ],

              ),
            ),
            Container( height: 100, width: 300, color: Colors.blueGrey[20],
              child: Column(
                children: <Widget>[
                  Text("  Choose scale area to design 3D map ",
                    style: TextStyle(fontSize: 16,color: Colors.black),textAlign: TextAlign.center,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      RaisedButton(
                        color: Colors.orangeAccent,
                        textColor: Colors.white,
                        highlightColor: Colors.red,
                        onPressed: (){},
                        child: Text(" 100m X 100m ",style: TextStyle(fontSize: 14)),
                      ),
                    ],
                  ),
                ],

              ),
            ),

          ],
          ),

        ) ,

      ),
    );
  }
}


